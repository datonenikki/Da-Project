﻿public enum CellType
{
    WallCorner = 2,
    WallHorizontal = 0,
    WallVertical = 1,
    Empty = 3,
}